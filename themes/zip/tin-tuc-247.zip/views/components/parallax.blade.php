


    
                <!-- ========== BEGIN PARALLAX ========== -->                 
                <div id="parallax-section"> 
                    <div class="image1 img-overlay1"> 
                        <div class="container"> 
                            <div class="caption text-center"> 
                                <div class="color-white text-center weight-300 medium-caption">Get the latest breaking news and top news headlines</div>                                 
                                <div class="color-white text-center weight-800 large-caption">Happening now on 24h News Channel</div>                                 
                                <div class="color-white text-center weight-400 medium-caption">No one hurt in North Side blaze</div>                                 
                                <h5>A fire that broke out Tuesday afternoon in the Park West, forcing residents to evacuate, is under control and no one was hurt.</h5> 
                            </div>                             
                        </div>                         
                    </div>                     
                </div>                 
                <!-- ========== END PARALLAX ========== -->        